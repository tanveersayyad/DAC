class DataConversionDemo
{
	public static void main(String args[])
	{
		int a = 10;
		long b = 20;

		a = (int)b;

		System.out.println(a);

	}
}
