class DataConversionDemo1
{
	public static void main(String args[])
	{
		int a = 260;
		byte b;

		b = (byte)a;

		System.out.println(b);

		int i;
		double d = 23.5;
		i = (int)d;
		System.out.println(i);

	}
}
