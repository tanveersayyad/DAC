public class DataTypesDemo
{
	public static void main(String args[])
	{
		char ch = 'J';
		ch = ch + 1;
		System.out.println(ch);
	}
}
