class ScopeDemo1
{
	public static void main(String args[])
	{
		int num;
		num++;		//compilation error variable num might not have been initialized
	}
}
