class LiteralsDemo2
{
	public static void main(String args[])
	{
		System.out.println("\"Hello Friends\"");		// "Hello Friends"

		//char ch = 65;
		//char ch = 'A';
		//char ch = '\101';
		char ch = '\u0041';
		System.out.println(ch);

		System.out.println("x = y \\ z");
	}
}
