class LiteralsDemo
{
	public static void main(String args[])
	{
		int a = 0x2F; 
		System.out.println(a);
	}
}
