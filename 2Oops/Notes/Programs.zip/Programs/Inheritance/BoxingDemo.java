class BoxingDemo {

	int fun(Integer v) 
	{
		return v;
	}
	
	public static void main(String args[ ]) 
	{
		Integer iob = fun(100);
		System.out.println(iob);
	} 
}

