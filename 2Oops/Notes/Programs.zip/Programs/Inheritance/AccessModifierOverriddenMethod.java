class A
{
	protected void myFun()
	{
	}
}

class B extends A
{
	private void myFun()
	{
	}
}

class AccessModifierOverriddenMethod
{
	public static void main(String args[])
	{

	}
}
