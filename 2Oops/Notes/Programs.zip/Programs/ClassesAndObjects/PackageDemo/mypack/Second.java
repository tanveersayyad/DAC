package mypack;	//It says whatever class we define here inside this file, all will belong to the package mypack.

public class Second
{
	public void myFun()
	{
		System.out.println("myFun of Second");
	}
}



