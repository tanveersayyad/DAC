package mypack;

public class First
{
	public void myFun()
	{
		System.out.println("myFun of First");
	}
}
