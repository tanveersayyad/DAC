//import mypack.First;
//import mypack.Second;

import mypack.*;

class UseMypackDemo
{
	public static void main(String args[])
	{
		First f = new First();
		f.myFun();

		Second s = new Second();
		s.myFun();

		Third t = new Third();
		t.myFun();
	}
}


