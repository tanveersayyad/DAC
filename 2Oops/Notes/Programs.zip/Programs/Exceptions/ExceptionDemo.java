class ExceptionDemo
{
	public static void main(String args[])
	{
		int a = 10;
		int b = 5;		//change value of b to 0
		
		System.out.println("Calculating the result");
		
		int res = a/b;
		
		System.out.println("result = " + res);
		
		int arr[] = {5,10,15,20,25};
		
		System.out.println(arr[5]);
		
		System.out.println("Program executed successfully");
	}
}
