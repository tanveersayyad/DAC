class MyException extends Exception
{
}

class UserDefinedExceptionDemo
{
	public static void main(String args[])
	{
	}
}
